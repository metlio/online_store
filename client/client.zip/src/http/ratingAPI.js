// import RatingStore from "../store/ShapochkaStore";
// import {$authHost, $host, $manageHost} from "./index";
// import axios from "axios";
// // export const createRating = async (rating) => {
// //     const {data} = await $authHost.post('api/rating', rating)
// //     return data
// // }

// export const fetchRating = async () => {
//     const {data} = await $host.get('api/rating')
//     return data
// }


// export const editRating = async () => {
//     const {data} = await $authHost.patch("api/device/8", {
//     rating: '1'
//   })
//   return data
//   }

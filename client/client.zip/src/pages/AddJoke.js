const AddJoke = () => {

    return  <h1>Add Joke Page</h1>;
    
};

export default AddJoke;
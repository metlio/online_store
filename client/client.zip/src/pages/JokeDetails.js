const JokeDetails = () => {

    return <h1>Jokes Details</h1>;
};

export default JokeDetails;
const Jokes = () => {
    return <h1>Jokes Page</h1>;
};

export default Jokes;
const PromoText = () => {
    return <section style={{textAlign:'center', paddingTop:'3rem'}}>
        <h2>Онлайн Суши Ресторан Япона Кухня</h2>
        <p>
            Здесь будет текстовочка раздела
        </p>
    </section>
}

export default PromoText;
import React, {useContext} from 'react';
import Logo from './Logo';
import styles from './Menu.module.css';
import NavBar from './NavBar';


function Menu() {

    return (
      <div style={{ display:'flex', alignItems:'center',opacity:'95%', backgroundColor:'#171717', justifyContent:'space-between', padding:'3px',paddingRight:'13%', zIndex:'100'}}>
          <div style={{ paddingLeft:'2rem' }}>
        <Logo />
        </div>
      <span className={styles.tip}>BETTER DESIGN WORLDWIDE</span>
      <div className={styles.tip}>MAGAZINE</div>
      <div className={styles.tip}>CONTACTS</div>
      <div>
      <NavBar />
      </div>
      </div>
      
    )
}

    export default Menu;

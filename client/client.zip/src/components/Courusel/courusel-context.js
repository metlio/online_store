import { createContext } from "react";

export const CouruselContext = createContext()